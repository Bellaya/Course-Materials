package org.eclipse.paho.client.mqttv3.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.apache.commons.codec.binary.Base64;

public class ImageToString {
	public String ImageToString(String url){
		File file = new File(url);
		FileInputStream imageInFile;
		String imageDataString="";
		try {
			imageInFile = new FileInputStream(file);
			byte imageData[] = new byte[(int)file.length()];
			imageInFile.read(imageData);
			
			
		 imageDataString = encodeImage(imageData);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Image Successfully Converted!");
		return imageDataString;
	}
	
	public void stringToImage(String imageDataString, String outPutPath){
		byte[] imageByteArray = decodeImage(imageDataString);
		
		/*
		 * Write a image byte array into file system  
		 */
		FileOutputStream imageOutFile;
		try {
			imageOutFile = new FileOutputStream(outPutPath);
			imageOutFile.write(imageByteArray);
			
			imageOutFile.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Image Successfully Generated!");
		
	}
	

	public String encodeImage(byte[] imageByteArray){	
		//return Base64.encodeBase64(imageByteArray).toString();
		return Base64.encodeBase64URLSafeString(imageByteArray);		
	}
	

	public byte[] decodeImage(String imageDataString) {		
		return Base64.decodeBase64(imageDataString);
	}
}