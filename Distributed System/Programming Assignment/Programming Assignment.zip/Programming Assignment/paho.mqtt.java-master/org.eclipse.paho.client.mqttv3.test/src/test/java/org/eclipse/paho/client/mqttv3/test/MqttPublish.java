package org.eclipse.paho.client.mqttv3.test;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MqttPublish {

    public static void main(String[] args) {
    	ImageToString IM=new ImageToString();

        String topic        = "dog";
       String url="D:/Get/DS/dog.jpg";
       
        //String url = "D:/Get/paho.mqtt.java-master/org.eclipse.paho.client.mqttv3.test/src/test/java/org/eclipse/paho/client/mqttv3/test/dog.jpg"; 
        String content=IM.ImageToString(url);
        System.out.println(content);
        String topic2        = "dog/puppy";
        String content2      = "Message from Bellaya Mamama ANd Dad puppy";
        int qos             = 2;
        String broker       = "tcp://143.248.236.36:1883";
        String clientId     = "Client1";
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);
            System.out.println("Connecting to broker: "+broker);
            sampleClient.connect(connOpts);
            System.out.println("Connected");
            System.out.println("Publishing message .....");
            MqttMessage message = new MqttMessage(content.getBytes());
            MqttMessage message2 = new MqttMessage(content2.getBytes());
            message.setQos(qos);
            sampleClient.publish(topic, message);
           // sampleClient.publish(topic2, message2);
           // System.out.println("Message published");
            sampleClient.disconnect();
            System.out.println("Disconnected");
            System.exit(0);
        } catch(MqttException me) {
            System.out.println("reason "+me.getReasonCode());
            System.out.println("msg "+me.getMessage());
            System.out.println("loc "+me.getLocalizedMessage());
            System.out.println("cause "+me.getCause());
            System.out.println("excep "+me);
            me.printStackTrace();
        }
    }
}