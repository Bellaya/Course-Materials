package org.eclipse.paho.client.mqttv3.test;

public interface ManualTest {

}
