import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Toolkit;
import javax.swing.UIManager;

public class pubGUI {

	private JFrame frmPublisherWindow;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Throwable e) {
			e.printStackTrace();
		}
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pubGUI window = new pubGUI();
					window.frmPublisherWindow.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public pubGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmPublisherWindow = new JFrame();
		frmPublisherWindow.setIconImage(Toolkit.getDefaultToolkit().getImage("D:\\Get\\DS\\Abc.jpg"));
		frmPublisherWindow.setFont(new Font("Dialog", Font.BOLD, 13));
		frmPublisherWindow.setForeground(new Color(0, 128, 128));
		frmPublisherWindow.setBackground(new Color(119, 136, 153));
		frmPublisherWindow.setTitle("Publisher Window");
		frmPublisherWindow.setBounds(100, 100, 450, 300);
		frmPublisherWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmPublisherWindow.getContentPane().setLayout(null);
		
		JButton btnPublish = new JButton("Publish");
		btnPublish.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) 
			{
				
			}
		});
		btnPublish.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent arg0) 
			{
				JOptionPane.showMessageDialog(null, "Message Published");
			}
		});
		btnPublish.setForeground(new Color(128, 0, 0));
		btnPublish.setBackground(Color.GRAY);
		btnPublish.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnPublish.setBounds(98, 166, 77, 23);
		frmPublisherWindow.getContentPane().add(btnPublish);
		
		JLabel lblPath = new JLabel("Path");
		lblPath.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		lblPath.setBounds(29, 87, 46, 14);
		frmPublisherWindow.getContentPane().add(lblPath);
		
		JLabel lblTopic = new JLabel("Topic");
		lblTopic.setFont(new Font("Comic Sans MS", Font.BOLD, 12));
		lblTopic.setBounds(29, 122, 46, 14);
		frmPublisherWindow.getContentPane().add(lblTopic);
		
		textField = new JTextField();
		textField.setToolTipText("");
		textField.setBounds(76, 85, 280, 20);
		frmPublisherWindow.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(76, 120, 280, 20);
		frmPublisherWindow.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblPublisherWindow = new JLabel("Publisher Window");
		lblPublisherWindow.setForeground(new Color(139, 69, 19));
		lblPublisherWindow.setBackground(new Color(205, 92, 92));
		lblPublisherWindow.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblPublisherWindow.setBounds(76, 11, 256, 51);
		frmPublisherWindow.getContentPane().add(lblPublisherWindow);
	}
}
