Please fill out the form below before submitting, thank you!

- [ ] Bug exists Release Version 1.1.0 ( Master Branch)
- [ ] Bug exists in Snapshot Version 1.1.1-SNAPSHOT (Develop Branch)

If this is a bug regarding the Android Service, please raise the bug here instead: https://github.com/eclipse/paho.mqtt.android/issues/new
