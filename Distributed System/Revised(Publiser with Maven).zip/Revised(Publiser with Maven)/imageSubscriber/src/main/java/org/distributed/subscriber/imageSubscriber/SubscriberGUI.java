package org.distributed.subscriber.imageSubscriber;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;

public class SubscriberGUI {

	public static JFrame frame;
	public static JTextField textField;
	public static JLabel label;
	public static JLabel lblTopic;
	public static JButton btnNewButton;
	public static JButton btnUnsubscriber;
	public static JLabel lblSubscriberWindow;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SubscriberGUI window = new SubscriberGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public SubscriberGUI() {
		initialize();
	}
	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 625, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		lblTopic = new JLabel("Topic");    // 
		lblTopic.setBounds(27, 68, 46, 14);
		frame.getContentPane().add(lblTopic);
		
		btnNewButton = new JButton("Subscribe");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MqttSubscribe smc = new MqttSubscribe();
		        smc.subscribeWithTopic(textField.getText());
				JOptionPane.showMessageDialog(null, "Subscription Succeded");
			}
		});
		btnNewButton.setBounds(74, 100, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		btnUnsubscriber = new JButton("Unsubscriber");
		btnUnsubscriber.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(null, "Unsubscription Succeded");
			}
		});
		btnUnsubscriber.setBounds(240, 97, 108, 23);
		frame.getContentPane().add(btnUnsubscriber);
		
		textField = new JTextField();
		textField.setBounds(74, 65, 86, 20);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		lblSubscriberWindow = new JLabel("Subscriber Window");
		lblSubscriberWindow.setBounds(95, 11, 121, 28);
		frame.getContentPane().add(lblSubscriberWindow);
		
		label = new JLabel("");
		label.setBounds(27, 149, 552, 301);
		frame.getContentPane().add(label);
		ImageIcon imgThisImg = new ImageIcon(MqttSubscribe.imagepath);

		label.setIcon(imgThisImg);
	}
}
