package org.distributed.subscriber.imageSubscriber;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import org.distributed.subscriber.imageSubscriber.StringToImage;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttTopic;
 
public class MqttSubscribe implements MqttCallback {
	
 public static String imagepath="C:/Users/choip_000/Desktop/subscribe/dog5.jpg";
 
  MqttClient myClient;
  MqttConnectOptions connOpt;
 
    static final String broker = "tcp://143.248.236.36:1883";
    
    // the following two flags control whether this example is a publisher, a subscriber or both
    static final Boolean subscriber = true;
    static final Boolean connect = true;
 
    /**
     * 
     * connectionLost
     * This callback is invoked upon losing the MQTT connection.
     * 
     */
//    @Override
//    public void connectionLost(Throwable t) {
//        System.out.println("Connection lost!");
//        // code to reconnect to the broker would go here if desired
//    }
 
    /**
     * 
     * deliveryComplete
     * This callback is invoked when a message published by this client
     * is successfully received by the broker.
     * 
     */
   // @Override
//    public void deliveryComplete(MqttDeliveryToken token) {
//        //System.out.println("Pub complete" + new String(token.getMessage().getPayload()));
//    }
 
    /**
     * 
     * messageArrived
     * This callback is invoked when a message is received on a subscribed topic.
     * 
     */
    //@Override
//    public void messageArrived(MqttTopic topic, MqttMessage message) throws Exception {
//        System.out.println("-------------------------------------------------");
//        System.out.println("| Topic:" + topic.getName());
//        System.out.println("| Message: " + new String(message.getPayload()));
//        System.out.println("-------------------------------------------------");
//    }
 
    /**
     * 
     * MAIN
     * 
     */
    public static void main(String[] args) {
    	MqttSubscribe smc = new MqttSubscribe();
        smc.runClient();
    }
     
    /**
     * 
     * runClient
     * The main functionality of this simple example.
     * Create a MQTT client, connect to broker, pub/sub, disconnect.
     * 
     */
    public void runClient() {
        // setup MQTT Client
        String clientID = "client1";
        connOpt = new MqttConnectOptions();
         
        connOpt.setCleanSession(true);
        connOpt.setKeepAliveInterval(30);
   
         
        // Connect to Broker
        try {
            myClient = new MqttClient(broker, clientID);
            myClient.setCallback(this);
            myClient.connect(connOpt);
        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(-1);
        }
         
        System.out.println("Connected to " + broker);
 
        // setup topic
        // topics on m2m.io are in the form <domain>/<stuff>/<thing>
        //String myTopic = M2MIO_DOMAIN + "/" + M2MIO_STUFF + "/" + M2MIO_THING;
        String myTopic ="dog";
        MqttTopic topic = myClient.getTopic(myTopic);
        //String myTopic2 ="dog/puppy";
        //MqttTopic topic2 = myClient.getTopic(myTopic2);
 
        // subscribe to topic if subscriber
        if (subscriber) {
            try {
                int subQoS = 0;
                myClient.subscribe(myTopic, subQoS);
                //myClient.subscribe(myTopic2, subQoS);;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
 
                 
        // disconnect
        try {
            // wait to ensure subscribed messages are delivered
            if (subscriber) {
                //Thread.sleep(50000);
                while(connect){
                	Thread.sleep(50000);
                }
            }
            myClient.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public void subscribeWithTopic(String topicString) {
        // setup MQTT Client
        String clientID = "client1";
        connOpt = new MqttConnectOptions();
         
        connOpt.setCleanSession(true);
        connOpt.setKeepAliveInterval(30);
   
         
        // Connect to Broker
        try {
            myClient = new MqttClient(broker, clientID);
            myClient.setCallback(this);
            myClient.connect(connOpt);
        } catch (MqttException e) {
            e.printStackTrace();
            System.exit(-1);
        }
         
        System.out.println("Connected to " + broker);
 
        // setup topic
        // topics on m2m.io are in the form <domain>/<stuff>/<thing>
        //String myTopic = M2MIO_DOMAIN + "/" + M2MIO_STUFF + "/" + M2MIO_THING;
        String myTopic =topicString;
        MqttTopic topic = myClient.getTopic(myTopic);
        //String myTopic2 ="dog/puppy";
        //MqttTopic topic2 = myClient.getTopic(myTopic2);
 
        // subscribe to topic if subscriber
        if (subscriber) {
            try {
                int subQoS = 0;
                myClient.subscribe(myTopic, subQoS);
                //myClient.subscribe(myTopic2, subQoS);;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
 
                 
        // disconnect
        try {
            // wait to ensure subscribed messages are delivered
            if (subscriber) {
                //Thread.sleep(50000);
                while(connect){
                	Thread.sleep(50000);
                }
            }
            myClient.disconnect();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

//	@Override
//	public void messageArrived(String topic, MqttMessage message) throws Exception {
//		// TODO Auto-generated method stub
//        System.out.println("-------------------------------------------------");
//        System.out.println("| Topic:" + topic);
//        StringToImage sti=new StringToImage();
//        String imageData=new String(message.getPayload());
//        sti.stringToImage(imageData, "C:/Users/choip_000/Desktop/subscribe/dog5.jpg");
//         System.out.println("| Message: " + new String(message.getPayload()));
//        System.out.println("-------------------------------------------------");
//		
//	}

//	@Override
//	public void deliveryComplete(IMqttDeliveryToken token) {
//		// TODO Auto-generated method stub
//		
//	}

	public void messageArrived(String topic, MqttMessage message) throws Exception {
		 System.out.println("-------------------------------------------------");
	        System.out.println("| Topic:" + topic);
	        StringToImage sti=new StringToImage();
	        String imageData=new String(message.getPayload());
	        sti.stringToImage(imageData, "C:/Users/choip_000/Desktop/subscribe/dog6.jpg");
	        
	        
//	        ImageIcon imgThisImg = new ImageIcon("C:/Users/choip_000/Desktop/subscribe/dog6.jpg");
//	        imgThisImg.getImage().flush();
//	        SubscriberGUI.label.setIcon(imgThisImg);
	        MqttSubscribe.imagepath="C:/Users/choip_000/Desktop/subscribe/dog6.jpg";
	        
//	        SubscriberGUI sub=new SubscriberGUI();
//	        sub.main(null);
	        //sub.r
//
//	        SubscriberGUI.frame.getContentPane().removeAll();
//	        
//	        SubscriberGUI.frame.getContentPane().add(SubscriberGUI.lblTopic);
//	        SubscriberGUI.frame.getContentPane().add(SubscriberGUI.btnNewButton);
//	        SubscriberGUI.frame.getContentPane().add(SubscriberGUI.btnUnsubscriber);
//	        SubscriberGUI.frame.getContentPane().add(SubscriberGUI.lblSubscriberWindow);
//	        
//	        SubscriberGUI.frame.revalidate();
//	        SubscriberGUI.frame.repaint();
//	        SubscriberGUI.frame.validate();
	        
//	        JLabel label = new JLabel();
//	        label.setBounds(27, 149, 552, 301);
//	        label.setVisible(true);
//	        label.setIcon(imgThisImg);
//	        label.setText("count");

//	        JPanel panel = new JPanel();
//	        panel.setVisible(true);
//	        panel.add(label);

	       // SubscribeGUI2.frame.getContentPane().removeAll();
	       // SubscribeGUI2.frame.getContentPane().add(panel);

	       // SubscribeGUI2.frame.repaint();
	       // SubscribeGUI2.frame.validate();
//	        JFrame frame2 = new JFrame();
//			frame2 = new JFrame();
//			frame2.setBounds(100, 100, 625, 500);
//			frame2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//			frame2.getContentPane().setLayout(null);
//			frame2.getContentPane().add(label);
//			frame2.setVisible(true);

//			Image image=new Image("C:/Users/choip_000/Desktop/subscribe/dog6.jpg");
//			frame2.setIconImage(image);
	        
//			frame2.add(new JLabel(new ImageIcon("C:/Users/choip_000/Desktop/subscribe/dog6.jpg")));
//			frame2.repaint();
//		    frame2.validate();
	        //SubscribeGUI2.frame.getContentPane().removeAll();
	        //SubscriberGUI.label.
	        System.out.println("| Message: " + new String(message.getPayload()));
	        System.out.println("---------------------------------------- ---------Here");
		
	}

	public void deliveryComplete(IMqttDeliveryToken token) {
		// TODO Auto-generated method stub
		
	}

	public void connectionLost(Throwable cause) {
		// TODO Auto-generated method stub
		
	}
}